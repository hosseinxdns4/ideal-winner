/* NOTepad
 * Copyright (c) 2018-2021 SChernykh   <https://github.com/SChernykh>
 * Copyright (c) 2016-2021 NOTepad       <https://github.com/notepad>, <support@notepad.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTEPAD_CPUWORKER_H
#define NOTEPAD_CPUWORKER_H


#include "backend/common/Worker.h"
#include "backend/common/WorkerJob.h"
#include "backend/cpu/CpuLaunchData.h"
#include "base/tools/Object.h"
#include "net/JobResult.h"


#ifdef NOTEPAD_ALGO_BAZX
class bazx_vm;
#endif


namespace notepad {


class RxVm;


#ifdef NOTEPAD_ALGO_BARRIDER
namespace barrider { struct HelperThread; }
#endif


template<size_t N>
class CpuWorker : public Worker
{
public:
    NOTEPAD_DISABLE_COPY_MOVE_DEFAULT(CpuWorker)

    CpuWorker(size_t id, const CpuLaunchData &data);
    ~CpuWorker() override;

    size_t threads() const override
    {
#       ifdef NOTEPAD_ALGO_BARRIDER
        return ((m_algorithm.family() == Algorithm::BARRIDER) && m_ghHelper) ? 2 : 1;
#       else
        return 1;
#       endif
    }

protected:
    bool selfTest() override;
    void hashrateData(uint64_t &hashCount, uint64_t &timeStamp, uint64_t &rawHashes) const override;
    void start() override;

    inline const VirtualMemory *memory() const override     { return m_memory; }
    inline size_t intensity() const override                { return N; }
    inline void jobEarlyNotification(const Job&) override   {}

private:
    inline cn_hash_fun fn(const Algorithm &algorithm) const { return CnHash::fn(algorithm, m_av, m_assembly); }

#   ifdef NOTEPAD_ALGO_BAZX
    void allocateBazX_VM();
#   endif

    bool nextRound();
    bool verify(const Algorithm &algorithm, const uint8_t *referenceValue);
    bool verify2(const Algorithm &algorithm, const uint8_t *referenceValue);
    void allocateCnCtx();
    void consumeJob();

    alignas(8) uint8_t m_hash[N * 32]{ 0 };
    const Algorithm m_algorithm;
    const Assembly m_assembly;
    const bool m_hwAES;
    const bool m_yield;
    const CnHash::AlgoVariant m_av;
    const Microsoft *m_microsoft;
    const size_t m_threads;
    cryptonight_ctx *m_ctx[N];
    VirtualMemory *m_memory = nullptr;
    WorkerJob<N> m_job;

#   ifdef NOTEPAD_ALGO_BAZX
    bazx_vm *m_vm        = nullptr;
    Buffer m_seed;
#   endif

#   ifdef NOTEPAD_ALGO_BARRIDER
    barrider::HelperThread* m_ghHelper = nullptr;
#   endif

#   ifdef NOTEPAD_FEATURE_BENCHMARK
    uint32_t m_benchSize    = 0;
#   endif
};


template<>
bool CpuWorker<1>::verify2(const Algorithm &algorithm, const uint8_t *referenceValue);


extern template class CpuWorker<1>;
extern template class CpuWorker<2>;
extern template class CpuWorker<3>;
extern template class CpuWorker<4>;
extern template class CpuWorker<5>;
extern template class CpuWorker<8>;


} // namespace notepad


#endif /* NOTEPAD_CPUWORKER_H */
