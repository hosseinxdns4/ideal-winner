if (WITH_ASM AND NOT NOTEPAD_ARM AND CMAKE_SIZEOF_VOID_P EQUAL 8)
    set(NOTEPAD_ASM_LIBRARY "notepad-asm")

    if (CMAKE_C_COMPILER_ID MATCHES MSVC)
        enable_language(ASM_MASM)

        if (MSVC_TOOLSET_VERSION GREATER_EQUAL 141)
            set(NOTEPAD_ASM_FILES
                "src/ct/cn/asm/cn_main_loop.asm"
                "src/ct/cn/asm/CtnightR_template.asm"
            )
        else()
            set(NOTEPAD_ASM_FILES
                "src/ct/cn/asm/win64/cn_main_loop.asm"
                "src/ct/cn/asm/win64/CtnightR_template.asm"
            )
        endif()

        set_property(SOURCE ${NOTEPAD_ASM_FILES} PROPERTY ASM_MASM)
    else()
        enable_language(ASM)

        if (WIN32 AND CMAKE_C_COMPILER_ID MATCHES GNU)
            set(NOTEPAD_ASM_FILES
                "src/ct/cn/asm/win64/cn_main_loop.S"
                "src/ct/cn/asm/CtnightR_template.S"
            )
        else()
            set(NOTEPAD_ASM_FILES
                "src/ct/cn/asm/cn_main_loop.S"
                "src/ct/cn/asm/CtnightR_template.S"
            )
        endif()

        set_property(SOURCE ${NOTEPAD_ASM_FILES} PROPERTY C)
    endif()

    add_library(${NOTEPAD_ASM_LIBRARY} STATIC ${NOTEPAD_ASM_FILES})
    set(NOTEPAD_ASM_SOURCES
        src/ct/common/Assembly.h
        src/ct/common/Assembly.cpp
        src/ct/cn/r/CtnightR_gen.cpp
        )
    set_property(TARGET ${NOTEPAD_ASM_LIBRARY} PROPERTY LINKER_LANGUAGE C)

    add_definitions(/DNOTEPAD_FEATURE_ASM)
else()
    set(NOTEPAD_ASM_SOURCES "")
    set(NOTEPAD_ASM_LIBRARY "")

    remove_definitions(/DNOTEPAD_FEATURE_ASM)
endif()
