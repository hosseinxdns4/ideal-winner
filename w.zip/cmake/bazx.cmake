if (WITH_BAZX)
    add_definitions(/DNOTEPAD_ALGO_BAZX)
    set(WITH_ARGON2 ON)

    list(APPEND HEADERS_CRYPTO
        src/ct/rx/Rx.h
        src/ct/rx/RxAlgo.h
        src/ct/rx/RxBasicStorage.h
        src/ct/rx/RxCache.h
        src/ct/rx/RxConfig.h
        src/ct/rx/RxDataset.h
        src/ct/rx/RxQueue.h
        src/ct/rx/RxSeed.h
        src/ct/rx/RxVm.h
    )

    list(APPEND SOURCES_CRYPTO
        src/ct/bazx/aes_hash.cpp
        src/ct/bazx/allocator.cpp
        src/ct/bazx/blake2_generator.cpp
        src/ct/bazx/blake2/blake2b.c
        src/ct/bazx/bytecode_machine.cpp
        src/ct/bazx/dataset.cpp
        src/ct/bazx/instructions_portable.cpp
        src/ct/bazx/bazx.cpp
        src/ct/bazx/reciprocal.c
        src/ct/bazx/soft_aes.cpp
        src/ct/bazx/superscalar.cpp
        src/ct/bazx/virtual_machine.cpp
        src/ct/bazx/virtual_memory.cpp
        src/ct/bazx/vm_compiled_light.cpp
        src/ct/bazx/vm_compiled.cpp
        src/ct/bazx/vm_interpreted_light.cpp
        src/ct/bazx/vm_interpreted.cpp
        src/ct/rx/Rx.cpp
        src/ct/rx/RxAlgo.cpp
        src/ct/rx/RxBasicStorage.cpp
        src/ct/rx/RxCache.cpp
        src/ct/rx/RxConfig.cpp
        src/ct/rx/RxDataset.cpp
        src/ct/rx/RxQueue.cpp
        src/ct/rx/RxVm.cpp
    )

    if (WITH_ASM AND CMAKE_C_COMPILER_ID MATCHES MSVC)
        enable_language(ASM_MASM)
        list(APPEND SOURCES_CRYPTO
             src/ct/bazx/jit_compiler_x86_static.asm
             src/ct/bazx/jit_compiler_x86.cpp
            )
    elseif (WITH_ASM AND NOT NOTEPAD_ARM AND CMAKE_SIZEOF_VOID_P EQUAL 8)
        list(APPEND SOURCES_CRYPTO
             src/ct/bazx/jit_compiler_x86_static.S
             src/ct/bazx/jit_compiler_x86.cpp
            )
        # cheat because cmake and ccache hate each other
        set_property(SOURCE src/ct/bazx/jit_compiler_x86_static.S PROPERTY LANGUAGE C)
    elseif (NOTEPAD_ARM AND CMAKE_SIZEOF_VOID_P EQUAL 8)
        list(APPEND SOURCES_CRYPTO
             src/ct/bazx/jit_compiler_a64_static.S
             src/ct/bazx/jit_compiler_a64.cpp
            )
        # cheat because cmake and ccache hate each other
        if (CMAKE_GENERATOR STREQUAL Xcode)
            set_property(SOURCE src/ct/bazx/jit_compiler_a64_static.S PROPERTY LANGUAGE ASM)
        else()
            set_property(SOURCE src/ct/bazx/jit_compiler_a64_static.S PROPERTY LANGUAGE C)
        endif()
    else()
        list(APPEND SOURCES_CRYPTO
             src/ct/bazx/jit_compiler_fallback.cpp
            )
    endif()

    if (WITH_SSE4_1)
        list(APPEND SOURCES_CRYPTO src/ct/bazx/blake2/blake2b_sse41.c)

        if (CMAKE_C_COMPILER_ID MATCHES GNU OR CMAKE_C_COMPILER_ID MATCHES Clang)
            set_source_files_properties(src/ct/bazx/blake2/blake2b_sse41.c PROPERTIES COMPILE_FLAGS "-Ofast -msse4.1")
        endif()
    endif()

    if (WITH_AVX2)
        list(APPEND SOURCES_CRYPTO src/ct/bazx/blake2/avx2/blake2b_avx2.c)

        if (CMAKE_C_COMPILER_ID MATCHES GNU OR CMAKE_C_COMPILER_ID MATCHES Clang)
            set_source_files_properties(src/ct/bazx/blake2/avx2/blake2b_avx2.c PROPERTIES COMPILE_FLAGS "-Ofast -mavx2")
        endif()
    endif()

    if (CMAKE_CXX_COMPILER_ID MATCHES Clang)
        set_source_files_properties(src/ct/bazx/jit_compiler_x86.cpp PROPERTIES COMPILE_FLAGS -Wno-unused-const-variable)
    endif()

    if (WITH_HWLOC)
        list(APPEND HEADERS_CRYPTO
             src/ct/rx/RxNUMAStorage.h
            )

        list(APPEND SOURCES_CRYPTO
             src/ct/rx/RxNUMAStorage.cpp
            )
    endif()

    if (WITH_MSR AND NOT NOTEPAD_ARM AND CMAKE_SIZEOF_VOID_P EQUAL 8 AND (NOTEPAD_OS_WIN OR NOTEPAD_OS_LINUX))
        add_definitions(/DNOTEPAD_FEATURE_MSR)
        add_definitions(/DNOTEPAD_FIX_RYZEN)
        message("-- WITH_MSR=ON")

        if (NOTEPAD_OS_WIN)
            list(APPEND SOURCES_CRYPTO
                src/ct/rx/RxFix_win.cpp
                src/hw/msr/Msr_win.cpp
                )
        elseif (NOTEPAD_OS_LINUX)
            list(APPEND SOURCES_CRYPTO
                src/ct/rx/RxFix_linux.cpp
                src/hw/msr/Msr_linux.cpp
                )
        endif()

        list(APPEND HEADERS_CRYPTO
            src/ct/rx/RxFix.h
            src/ct/rx/RxMsr.h
            src/hw/msr/Msr.h
            src/hw/msr/MsrItem.h
            )

        list(APPEND SOURCES_CRYPTO
            src/ct/rx/RxMsr.cpp
            src/hw/msr/Msr.cpp
            src/hw/msr/MsrItem.cpp
            )
    else()
        remove_definitions(/DNOTEPAD_FEATURE_MSR)
        remove_definitions(/DNOTEPAD_FIX_RYZEN)
        message("-- WITH_MSR=OFF")
    endif()

    if (WITH_PROFILING)
        add_definitions(/DNOTEPAD_FEATURE_PROFILING)

        list(APPEND HEADERS_CRYPTO src/ct/rx/Profiler.h)
        list(APPEND SOURCES_CRYPTO src/ct/rx/Profiler.cpp)
    endif()
else()
    remove_definitions(/DNOTEPAD_ALGO_BAZX)
endif()
