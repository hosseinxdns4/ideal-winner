if (WITH_BAZX)
    add_definitions(/DNOTEPAD_ALGO_BAZX)
    set(WITH_ARGON2 ON)

    list(APPEND HEADERS_CRYPTO
        src/ct/wa/Wa.h
        src/ct/wa/WaAlgo.h
        src/ct/wa/WaBasicStorage.h
        src/ct/wa/WaCache.h
        src/ct/wa/WaConfig.h
        src/ct/wa/WaDataset.h
        src/ct/wa/WaQueue.h
        src/ct/wa/WaSeed.h
        src/ct/wa/WaVm.h
    )

    list(APPEND SOURCES_CRYPTO
        src/ct/bazx/aes_hash.cpp
        src/ct/bazx/allocator.cpp
        src/ct/bazx/blake2_generator.cpp
        src/ct/bazx/blake2/blake2b.c
        src/ct/bazx/bytecode_machine.cpp
        src/ct/bazx/dataset.cpp
        src/ct/bazx/instructions_portable.cpp
        src/ct/bazx/bazx.cpp
        src/ct/bazx/reciprocal.c
        src/ct/bazx/soft_aes.cpp
        src/ct/bazx/superscalar.cpp
        src/ct/bazx/virtual_machine.cpp
        src/ct/bazx/virtual_memory.cpp
        src/ct/bazx/vm_compiled_light.cpp
        src/ct/bazx/vm_compiled.cpp
        src/ct/bazx/vm_interpreted_light.cpp
        src/ct/bazx/vm_interpreted.cpp
        src/ct/wa/Wa.cpp
        src/ct/wa/WaAlgo.cpp
        src/ct/wa/WaBasicStorage.cpp
        src/ct/wa/WaCache.cpp
        src/ct/wa/WaConfig.cpp
        src/ct/wa/WaDataset.cpp
        src/ct/wa/WaQueue.cpp
        src/ct/wa/WaVm.cpp
    )

    if (WITH_ASM AND CMAKE_C_COMPILER_ID MATCHES MSVC)
        enable_language(ASM_MASM)
        list(APPEND SOURCES_CRYPTO
             src/ct/bazx/jit_compiler_x86_static.asm
             src/ct/bazx/jit_compiler_x86.cpp
            )
    elseif (WITH_ASM AND NOT NOTEPAD_ARM AND CMAKE_SIZEOF_VOID_P EQUAL 8)
        list(APPEND SOURCES_CRYPTO
             src/ct/bazx/jit_compiler_x86_static.S
             src/ct/bazx/jit_compiler_x86.cpp
            )
        # cheat because cmake and ccache hate each other
        set_property(SOURCE src/ct/bazx/jit_compiler_x86_static.S PROPERTY LANGUAGE C)
    elseif (NOTEPAD_ARM AND CMAKE_SIZEOF_VOID_P EQUAL 8)
        list(APPEND SOURCES_CRYPTO
             src/ct/bazx/jit_compiler_a64_static.S
             src/ct/bazx/jit_compiler_a64.cpp
            )
        # cheat because cmake and ccache hate each other
        if (CMAKE_GENERATOR STREQUAL Xcode)
            set_property(SOURCE src/ct/bazx/jit_compiler_a64_static.S PROPERTY LANGUAGE ASM)
        else()
            set_property(SOURCE src/ct/bazx/jit_compiler_a64_static.S PROPERTY LANGUAGE C)
        endif()
    else()
        list(APPEND SOURCES_CRYPTO
             src/ct/bazx/jit_compiler_fallback.cpp
            )
    endif()

    if (WITH_SSE4_1)
        list(APPEND SOURCES_CRYPTO src/ct/bazx/blake2/blake2b_sse41.c)

        if (CMAKE_C_COMPILER_ID MATCHES GNU OR CMAKE_C_COMPILER_ID MATCHES Clang)
            set_source_files_properties(src/ct/bazx/blake2/blake2b_sse41.c PROPERTIES COMPILE_FLAGS "-Ofast -msse4.1")
        endif()
    endif()

    if (WITH_AVX2)
        list(APPEND SOURCES_CRYPTO src/ct/bazx/blake2/avx2/blake2b_avx2.c)

        if (CMAKE_C_COMPILER_ID MATCHES GNU OR CMAKE_C_COMPILER_ID MATCHES Clang)
            set_source_files_properties(src/ct/bazx/blake2/avx2/blake2b_avx2.c PROPERTIES COMPILE_FLAGS "-Ofast -mavx2")
        endif()
    endif()

    if (CMAKE_CXX_COMPILER_ID MATCHES Clang)
        set_source_files_properties(src/ct/bazx/jit_compiler_x86.cpp PROPERTIES COMPILE_FLAGS -Wno-unused-const-variable)
    endif()

    if (WITH_HWLOC)
        list(APPEND HEADERS_CRYPTO
             src/ct/wa/WaNUMAStorage.h
            )

        list(APPEND SOURCES_CRYPTO
             src/ct/wa/WaNUMAStorage.cpp
            )
    endif()

    if (WITH_MSR AND NOT NOTEPAD_ARM AND CMAKE_SIZEOF_VOID_P EQUAL 8 AND (NOTEPAD_OS_WIN OR NOTEPAD_OS_LINUX))
        add_definitions(/DNOTEPAD_FEATURE_MSR)
        add_definitions(/DNOTEPAD_FIX_RYZEN)
        message("-- WITH_MSR=ON")

        if (NOTEPAD_OS_WIN)
            list(APPEND SOURCES_CRYPTO
                src/ct/wa/WaFix_win.cpp
                src/hw/msr/Msr_win.cpp
                )
        elseif (NOTEPAD_OS_LINUX)
            list(APPEND SOURCES_CRYPTO
                src/ct/wa/WaFix_linux.cpp
                src/hw/msr/Msr_linux.cpp
                )
        endif()

        list(APPEND HEADERS_CRYPTO
            src/ct/wa/WaFix.h
            src/ct/wa/WaMsr.h
            src/hw/msr/Msr.h
            src/hw/msr/MsrItem.h
            )

        list(APPEND SOURCES_CRYPTO
            src/ct/wa/WaMsr.cpp
            src/hw/msr/Msr.cpp
            src/hw/msr/MsrItem.cpp
            )
    else()
        remove_definitions(/DNOTEPAD_FEATURE_MSR)
        remove_definitions(/DNOTEPAD_FIX_RYZEN)
        message("-- WITH_MSR=OFF")
    endif()

    if (WITH_PROFILING)
        add_definitions(/DNOTEPAD_FEATURE_PROFILING)

        list(APPEND HEADERS_CRYPTO src/ct/wa/Profiler.h)
        list(APPEND SOURCES_CRYPTO src/ct/wa/Profiler.cpp)
    endif()
else()
    remove_definitions(/DNOTEPAD_ALGO_BAZX)
endif()
