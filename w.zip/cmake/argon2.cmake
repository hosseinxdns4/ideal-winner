if (WITH_ARGON2)
    add_definitions(/DNOTEPAD_ALGO_ARGON2)

    list(APPEND HEADERS_CRYPTO
        src/ct/argon2/Hash.h
        src/ct/argon2/Impl.h
    )

    list(APPEND SOURCES_CRYPTO
        src/ct/argon2/Impl.cpp
    )

    add_subdirectory(src/3rdparty/argon2)
    set(ARGON2_LIBRARY argon2)
else()
    remove_definitions(/DNOTEPAD_ALGO_ARGON2)
    set(ARGON2_LIBRARY "")
endif()
