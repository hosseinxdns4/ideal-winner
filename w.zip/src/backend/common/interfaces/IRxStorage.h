/* NOTepad
 * Copyright (c) 2018-2019 tevador     <tevador@gmail.com>
 * Copyright (c) 2018-2020 SChernykh   <https://github.com/SChernykh>
 * Copyright (c) 2016-2020 NOTepad       <https://github.com/notepad>, <support@notepad.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTEPAD_IWASTORAGE_H
#define NOTEPAD_IWASTORAGE_H


#include "base/tools/Object.h"
#include "ct/common/HugePagesInfo.h"
#include "ct/wa/WaConfig.h"


#include <cstdint>
#include <utility>


namespace notepad {


class Job;
class WaDataset;
class WaSeed;


class IWaStorage
{
public:
    NOTEPAD_DISABLE_COPY_MOVE(IWaStorage)

    IWaStorage()            = default;
    virtual ~IWaStorage()   = default;

    virtual bool isAllocated() const                                                                                            = 0;
    virtual HugePagesInfo hugePages() const                                                                                     = 0;
    virtual WaDataset *dataset(const Job &job, uint32_t nodeId) const                                                           = 0;
    virtual void init(const WaSeed &seed, uint32_t threads, bool hugePages, bool oneGbPages, WaConfig::Mode mode, int priority) = 0;
};


} /* namespace notepad */


#endif // NOTEPAD_IWASTORAGE_H
