/* NOTepad
 * Copyright (c) 2018-2021 SChernykh   <https://github.com/SChernykh>
 * Copyright (c) 2016-2021 NOTepad       <https://github.com/notepad>, <support@notepad.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTEPAD_OCLWAJITRUNNER_H
#define NOTEPAD_OCLWAJITRUNNER_H


#include "backend/opencl/runners/OclWaBaseRunner.h"


namespace notepad {


class WaJitKernel;
class WaRunKernel;


class OclWaJitRunner : public OclWaBaseRunner
{
public:
    NOTEPAD_DISABLE_COPY_MOVE_DEFAULT(OclWaJitRunner)

    OclWaJitRunner(size_t index, const OclLaunchData &data);
    ~OclWaJitRunner() override;

protected:
    size_t bufferSize() const override;
    void build() override;
    void execute(uint32_t iteration) override;
    void init() override;

private:
    bool loadAsmProgram();

    cl_mem m_intermediate_programs  = nullptr;
    cl_mem m_programs               = nullptr;
    cl_mem m_registers              = nullptr;
    cl_program m_asmProgram         = nullptr;
    WaJitKernel *m_bazx_jit      = nullptr;
    WaRunKernel *m_bazx_run      = nullptr;
};


} /* namespace notepad */


#endif // NOTEPAD_OCLWARUNNER_H
