/* NOTepad
 * Copyright (c) 2018-2021 SChernykh   <https://github.com/SChernykh>
 * Copyright (c) 2016-2021 NOTepad       <https://github.com/notepad>, <support@notepad.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTEPAD_OCLWAVMRUNNER_H
#define NOTEPAD_OCLWAVMRUNNER_H


#include "backend/opencl/runners/OclWaBaseRunner.h"


namespace notepad {


class ExecuteVmKernel;
class InitVmKernel;


class OclWaVmRunner : public OclWaBaseRunner
{
public:
    NOTEPAD_DISABLE_COPY_MOVE_DEFAULT(OclWaVmRunner)

    OclWaVmRunner(size_t index, const OclLaunchData &data);
    ~OclWaVmRunner() override;

protected:
    size_t bufferSize() const override;
    void build() override;
    void execute(uint32_t iteration) override;
    void init() override;

private:
    cl_mem m_vm_states              = nullptr;
    ExecuteVmKernel *m_execute_vm   = nullptr;
    InitVmKernel *m_init_vm         = nullptr;
};


} /* namespace notepad */


#endif // NOTEPAD_OCLWAVMRUNNER_H
