if (BUILD_STATIC AND NOTEPAD_OS_UNIX AND WITH_OPENCL)
    message(WARNING "OpenCL backend is not compatible with static build, use -DWITH_OPENCL=OFF to suppress this warning")

    set(WITH_OPENCL OFF)
endif()

if (WITH_OPENCL)
    add_definitions(/DNOTEPAD_FEATURE_OPENCL)
    add_definitions(/DCL_USE_DEPRECATED_OPENCL_1_2_APIS)
    if (NOTEPAD_OS_APPLE)
        add_definitions(/DCL_TARGET_OPENCL_VERSION=120)
    elseif (WITH_OPENCL_VERSION)
        add_definitions(/DCL_TARGET_OPENCL_VERSION=${WITH_OPENCL_VERSION})
    endif()

    set(HEADERS_BACKEND_OPENCL
        src/backend/opencl/cl/OclSource.h
        src/backend/opencl/interfaces/IOclRunner.h
        src/backend/opencl/kernels/Cn0Kernel.h
        src/backend/opencl/kernels/Cn1Kernel.h
        src/backend/opencl/kernels/Cn2Kernel.h
        src/backend/opencl/kernels/CnBranchKernel.h
        src/backend/opencl/OclBackend.h
        src/backend/opencl/OclCache.h
        src/backend/opencl/OclConfig.h
        src/backend/opencl/OclConfig_gen.h
        src/backend/opencl/OclGenerator.h
        src/backend/opencl/OclLaunchData.h
        src/backend/opencl/OclThread.h
        src/backend/opencl/OclThreads.h
        src/backend/opencl/OclWorker.h
        src/backend/opencl/runners/OclBaseRunner.h
        src/backend/opencl/runners/OclCnRunner.h
        src/backend/opencl/runners/tools/OclCnR.h
        src/backend/opencl/runners/tools/OclSharedData.h
        src/backend/opencl/runners/tools/OclSharedState.h
        src/backend/opencl/wrappers/OclContext.h
        src/backend/opencl/wrappers/OclDevice.h
        src/backend/opencl/wrappers/OclError.h
        src/backend/opencl/wrappers/OclKernel.h
        src/backend/opencl/wrappers/OclLib.h
        src/backend/opencl/wrappers/OclPlatform.h
        src/backend/opencl/wrappers/OclVendor.h
        )

    set(SOURCES_BACKEND_OPENCL
        src/backend/opencl/cl/OclSource.cpp
        src/backend/opencl/generators/ocl_generic_cn_generator.cpp
        src/backend/opencl/generators/ocl_vega_cn_generator.cpp
        src/backend/opencl/kernels/Cn0Kernel.cpp
        src/backend/opencl/kernels/Cn1Kernel.cpp
        src/backend/opencl/kernels/Cn2Kernel.cpp
        src/backend/opencl/kernels/CnBranchKernel.cpp
        src/backend/opencl/OclBackend.cpp
        src/backend/opencl/OclCache.cpp
        src/backend/opencl/OclConfig.cpp
        src/backend/opencl/OclLaunchData.cpp
        src/backend/opencl/OclThread.cpp
        src/backend/opencl/OclThreads.cpp
        src/backend/opencl/OclWorker.cpp
        src/backend/opencl/runners/OclBaseRunner.cpp
        src/backend/opencl/runners/OclCnRunner.cpp
        src/backend/opencl/runners/tools/OclCnR.cpp
        src/backend/opencl/runners/tools/OclSharedData.cpp
        src/backend/opencl/runners/tools/OclSharedState.cpp
        src/backend/opencl/wrappers/OclContext.cpp
        src/backend/opencl/wrappers/OclDevice.cpp
        src/backend/opencl/wrappers/OclError.cpp
        src/backend/opencl/wrappers/OclKernel.cpp
        src/backend/opencl/wrappers/OclLib.cpp
        src/backend/opencl/wrappers/OclPlatform.cpp
        )

    if (WIN32)
        list(APPEND SOURCES_BACKEND_OPENCL src/backend/opencl/OclCache_win.cpp)
    else()
        list(APPEND SOURCES_BACKEND_OPENCL src/backend/opencl/OclCache_unix.cpp)
    endif()

    if (WITH_BAZX)
        list(APPEND HEADERS_BACKEND_OPENCL
             src/backend/opencl/kernels/wa/Blake2bHashRegistersKernel.h
             src/backend/opencl/kernels/wa/Blake2bInitialHashBigKernel.h
             src/backend/opencl/kernels/wa/Blake2bInitialHashDoubleKernel.h
             src/backend/opencl/kernels/wa/Blake2bInitialHashKernel.h
             src/backend/opencl/kernels/wa/ExecuteVmKernel.h
             src/backend/opencl/kernels/wa/FillAesKernel.h
             src/backend/opencl/kernels/wa/FindSharesKernel.h
             src/backend/opencl/kernels/wa/HashAesKernel.cpp
             src/backend/opencl/kernels/wa/InitVmKernel.h
             src/backend/opencl/kernels/wa/WaJitKernel.h
             src/backend/opencl/kernels/wa/WaRunKernel.h
             src/backend/opencl/runners/OclWaBaseRunner.h
             src/backend/opencl/runners/OclWaJitRunner.h
             src/backend/opencl/runners/OclWaVmRunner.h
             )

        list(APPEND SOURCES_BACKEND_OPENCL
             src/backend/opencl/generators/ocl_generic_wa_generator.cpp
             src/backend/opencl/kernels/wa/Blake2bHashRegistersKernel.cpp
             src/backend/opencl/kernels/wa/Blake2bInitialHashBigKernel.cpp
             src/backend/opencl/kernels/wa/Blake2bInitialHashDoubleKernel.cpp
             src/backend/opencl/kernels/wa/Blake2bInitialHashKernel.cpp
             src/backend/opencl/kernels/wa/ExecuteVmKernel.cpp
             src/backend/opencl/kernels/wa/FillAesKernel.cpp
             src/backend/opencl/kernels/wa/FindSharesKernel.cpp
             src/backend/opencl/kernels/wa/HashAesKernel.cpp
             src/backend/opencl/kernels/wa/InitVmKernel.cpp
             src/backend/opencl/kernels/wa/WaJitKernel.cpp
             src/backend/opencl/kernels/wa/WaRunKernel.cpp
             src/backend/opencl/runners/OclWaBaseRunner.cpp
             src/backend/opencl/runners/OclWaJitRunner.cpp
             src/backend/opencl/runners/OclWaVmRunner.cpp
             )
    endif()

    if (WITH_FOOPOW)
        list(APPEND HEADERS_BACKEND_OPENCL
             src/backend/opencl/kernels/foopow/FooPow_CalculateDAGKernel.h
             src/backend/opencl/runners/OclFooPowRunner.h
             src/backend/opencl/runners/tools/OclFooPow.h
             )

        list(APPEND SOURCES_BACKEND_OPENCL
             src/backend/opencl/generators/ocl_generic_foopow_generator.cpp
             src/backend/opencl/kernels/foopow/FooPow_CalculateDAGKernel.cpp
             src/backend/opencl/runners/OclFooPowRunner.cpp
             src/backend/opencl/runners/tools/OclFooPow.cpp
             )
    endif()

    if (WITH_STRICT_CACHE)
        add_definitions(/DNOTEPAD_STRICT_OPENCL_CACHE)
    else()
        remove_definitions(/DNOTEPAD_STRICT_OPENCL_CACHE)
    endif()

    if (WITH_INTERLEAVE_DEBUG_LOG)
        add_definitions(/DNOTEPAD_INTERLEAVE_DEBUG)
    endif()

    if (WITH_ADL AND (NOTEPAD_OS_WIN OR NOTEPAD_OS_LINUX))
        add_definitions(/DNOTEPAD_FEATURE_ADL)

        list(APPEND HEADERS_BACKEND_OPENCL
             src/backend/opencl/wrappers/AdlHealth.h
             src/backend/opencl/wrappers/AdlLib.h
             )

        if (NOTEPAD_OS_WIN)
            list(APPEND SOURCES_BACKEND_OPENCL src/backend/opencl/wrappers/AdlLib.cpp)
        else()
            list(APPEND SOURCES_BACKEND_OPENCL src/backend/opencl/wrappers/AdlLib_linux.cpp)
        endif()
    else()
       remove_definitions(/DNOTEPAD_FEATURE_ADL)
    endif()
else()
    remove_definitions(/DNOTEPAD_FEATURE_OPENCL)
    remove_definitions(/DNOTEPAD_FEATURE_ADL)

    set(HEADERS_BACKEND_OPENCL "")
    set(SOURCES_BACKEND_OPENCL "")
endif()
