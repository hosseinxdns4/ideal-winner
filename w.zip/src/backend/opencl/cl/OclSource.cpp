/* NOTepad
 * Copyright 2010      Jeff Garzik <jgarzik@pobox.com>
 * Copyright 2012-2014 pooler      <pooler@litecoinpool.org>
 * Copyright 2014      Lucas Jones <https://github.com/lucasjones>
 * Copyright 2014-2016 Wolf9466    <https://github.com/OhGodAPet>
 * Copyright 2016      Jay D Dee   <jayddee246@gmail.com>
 * Copyright 2017-2018 amd    <https://github.com/fireice-uk>, <https://github.com/psychocrypt>
 * Copyright 2018-2020 SChernykh   <https://github.com/SChernykh>
 * Copyright 2016-2020 NOTepad       <https://github.com/notepad>, <support@notepad.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */


#include "backend/opencl/cl/OclSource.h"
#include "backend/opencl/cl/cn/ctnight_cl.h"
#include "base/ct/Algorithm.h"


#ifdef NOTEPAD_ALGO_BAZX
#   include "backend/opencl/cl/rx/bazx_cl.h"
#endif

#ifdef NOTEPAD_ALGO_FOOPOW
#   include "backend/opencl/cl/foopow/foopow_cl.h"
#   include "backend/opencl/cl/foopow/foopow_dag_cl.h"
#endif


const char *notepad::OclSource::get(const Algorithm &algorithm)
{
#   ifdef NOTEPAD_ALGO_BAZX
    if (algorithm.family() == Algorithm::BAZ_X) {
        return bazx_cl;
    }
#   endif

#   ifdef NOTEPAD_ALGO_FOOPOW
    if (algorithm.family() == Algorithm::FOOPOW) {
        return foopow_dag_cl;
    }
#   endif

    return ctnight_cl;
}
