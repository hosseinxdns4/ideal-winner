#include "../cn/algorithm.cl"

#if ((ALGO == ALGO_WA_0) || (ALGO == ALGO_WA_YADA))
#include "bazx_constants_monero.h"
#elif (ALGO == ALGO_WA_WOW)
#include "bazx_constants_wow.h"
#elif (ALGO == ALGO_WA_ARQMA)
#include "bazx_constants_arqma.h"
#elif (ALGO == ALGO_WA_GRAFT)
#include "bazx_constants_graft.h"
#endif

#include "aes.cl"
#include "blake2b.cl"
#include "bazx_vm.cl"
#include "bazx_jit.cl"
