:: Example batch file for mining Mo solo
::
:: Format:
::	notepad.exe -o <node address>:<node port> -a rx/0 -u <wallet address> --daemon
::
:: Fields:
::	node address		The host name of your mod node or its IP address. It can also be a public node with RPC enabled, for example node.xf.to
::	node port 		The RPC port of your mod node to connect to, usually 18081.
::	wallet address		Check your Mo CLI or GUI wallet to see your wallet's address.
::
:: Mining solo is the best way to help Mo network be more decentralized!
:: But you will only get a payout when you find a block which can take more than a year for a single low-end PC.

cd /d "%~dp0"
notepad.exe -o YOUR_NODE_IP:18081 -a rx/0 -u 48edfHu7V9Z84YzzMa6fUueoELZ9ZRXq9VetWzYGzKt52XU5xvqgzYnDK9URnRoJMk1j8nLwEVsaSWJ4fhdUyZijBGUicoD --daemon
pause
