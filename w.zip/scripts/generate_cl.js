#!/usr/bin/env node

'use strict';

const fs = require('fs');
const path = require('path');
const { text2h, text2h_bundle, addIncludes } = require('./js/opencl');
const { opencl_minify } = require('./js/opencl_minify');
const cwd = process.cwd();


function cn()
{
    const cn = opencl_minify(addIncludes('ctnight.cl', [
        'algorithm.cl',
        'wolf-aes.cl',
        'wolf-skein.cl',
        'jh.cl',
        'blake256.cl',
        'groestl256.cl',
        'fast_int_math_v2.cl',
        'fast_div_heavy.cl',
        'keccak.cl'
    ]));

    // fs.writeFileSync('ctnight_gen.cl', cn);
    fs.writeFileSync('ctnight_cl.h', text2h(cn, 'notepad', 'ctnight_cl'));
}


function cn_r()
{
    const items = {};

    items.ctnight_r_defines_cl = opencl_minify(addIncludes('ctnight_r_defines.cl', [ 'wolf-aes.cl' ]));
    items.ctnight_r_cl         = opencl_minify(fs.readFileSync('ctnight_r.cl', 'utf8'));

    // for (let key in items) {
    //      fs.writeFileSync(key + '_gen.cl', items[key]);
    // }

    fs.writeFileSync('ctnight_r_cl.h', text2h_bundle('notepad', items));
}


function wa()
{
    let wa = addIncludes('bazx.cl', [
        '../cn/algorithm.cl',
        'bazx_constants_monero.h',
        'bazx_constants_wow.h',
        'bazx_constants_arqma.h',
        'bazx_constants_graft.h',
        'aes.cl',
        'blake2b.cl',
        'bazx_vm.cl',
        'bazx_jit.cl'
    ]);

    wa = wa.replace(/(\t| )*#include "fillAes1Wa4.cl"/g, fs.readFileSync('fillAes1Wa4.cl', 'utf8'));
    wa = wa.replace(/(\t| )*#include "blake2b_double_block.cl"/g, fs.readFileSync('blake2b_double_block.cl', 'utf8'));
    wa = opencl_minify(wa);

    //fs.writeFileSync('bazx_gen.cl', wa);
    fs.writeFileSync('bazx_cl.h', text2h(wa, 'notepad', 'bazx_cl'));
}


function foopow()
{
    const foopow = opencl_minify(addIncludes('foopow.cl', [ 'defs.h' ]));
    const foopow_dag = opencl_minify(addIncludes('foopow_dag.cl', [ 'defs.h' ]));

    // fs.writeFileSync('foopow_gen.cl', foopow);
    fs.writeFileSync('foopow_cl.h', text2h(foopow, 'notepad', 'foopow_cl'));
    fs.writeFileSync('foopow_dag_cl.h', text2h(foopow_dag, 'notepad', 'foopow_dag_cl'));
}


process.chdir(path.resolve('src/backend/opencl/cl/cn'));

cn();
cn_r();

process.chdir(cwd);
process.chdir(path.resolve('src/backend/opencl/cl/wa'));

wa();

process.chdir(cwd);
process.chdir(path.resolve('src/backend/opencl/cl/foopow'));

foopow();
