@echo off
cd /d "%~dp0"
notepad.exe --bench=10M --submit
pause
