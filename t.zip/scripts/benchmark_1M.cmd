@echo off
cd /d "%~dp0"
notepad.exe --bench=1M --submit
pause
