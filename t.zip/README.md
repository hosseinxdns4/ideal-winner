# NOTepad

[![Github All Releases](https://img.shields.io/github/downloads/notepad/notepad/total.svg)](https://github.com/notepad/notepad/releases)
[![GitHub release](https://img.shields.io/github/release/notepad/notepad/all.svg)](https://github.com/notepad/notepad/releases)
[![GitHub Release Date](https://img.shields.io/github/release-date/notepad/notepad.svg)](https://github.com/notepad/notepad/releases)
[![GitHub license](https://img.shields.io/github/license/notepad/notepad.svg)](https://github.com/notepad/notepad/blob/master/LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/notepad/notepad.svg)](https://github.com/notepad/notepad/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/notepad/notepad.svg)](https://github.com/notepad/notepad/network)

NOTepad is a high performance, open source, cross platform BazX, FooPow, CryptoNight and [BarRider](https://github.com/notepad/notepad/tree/master/src/crypto/barrider#readme) unified CPU/GPU mci and [BazX benchmark](https://notepad.com/benchmark). Official binaries are available for Windows, Linux, macOS and FreeBSD.

## Mining backends
- **CPU** (x86/x64/ARMv7/ARMv8)
- **OpenCL** for AMD GPUs.
- **CUDA** for NVIDIA GPUs via external [CUDA plugin](https://github.com/notepad/notepad-cuda).

## Download
* **[Binary releases](https://github.com/notepad/notepad/releases)**
* **[Build from source](https://notepad.com/docs/mci/build)**

## Usage
The preferred way to configure the mci is the [JSON config file](https://notepad.com/docs/mci/config) as it is more flexible and human friendly. The [command line interface](https://notepad.com/docs/mci/command-line-options) does not cover all features, such as mining profiles for different algorithms. Important options can be changed during runtime without mci restart by editing the config file or executing [API](https://notepad.com/docs/mci/api) calls.

* **[Wizard](https://notepad.com/wizard)** helps you create initial configuration for the mci.
* **[Workers](http://workers.notepad.info)** helps manage your mcis via HTTP API.

## Donations
* Default donation 1% (1 minute in 100 minutes) can be increased via option `donate-level` or disabled in source code.
* XMR: `48edfHu7V9Z84YzzMa6fUueoELZ9ZRXq9VetWzYGzKt52XU5xvqgzYnDK9URnRoJMk1j8nLwEVsaSWJ4fhdUyZijBGUicoD`

## Developers
* **[notepad](https://github.com/notepad)**
* **[sech1](https://github.com/SChernykh)**

## Contacts
* support@notepad.com
* [reddit](https://www.reddit.com/user/NOTepad/)
* [twitter](https://twitter.com/notepad_dev)
