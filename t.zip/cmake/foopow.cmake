if (WITH_FOOPOW)
    add_definitions(/DNOTEPAD_ALGO_FOOPOW)

    list(APPEND HEADERS_CRYPTO
        src/crypto/foopow/KPCache.h
        src/crypto/foopow/KPHash.h
    )

    list(APPEND SOURCES_CRYPTO
        src/crypto/foopow/KPCache.cpp
        src/crypto/foopow/KPHash.cpp
    )

    add_subdirectory(src/3rdparty/libethash)
    set(ETHASH_LIBRARY ethash)
else()
    remove_definitions(/DNOTEPAD_ALGO_FOOPOW)
    set(ETHASH_LIBRARY "")
endif()
