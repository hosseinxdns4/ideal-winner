/* NOTepad
 * Copyright (c) 2018-2019 tevador     <tevador@gmail.com>
 * Copyright (c) 2018-2020 SChernykh   <https://github.com/SChernykh>
 * Copyright (c) 2016-2020 NOTepad       <https://github.com/notepad>, <support@notepad.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTEPAD_IRXLISTENER_H
#define NOTEPAD_IRXLISTENER_H


#include "base/tools/Object.h"


namespace notepad {


class IRxListener
{
public:
    NOTEPAD_DISABLE_COPY_MOVE(IRxListener)

    IRxListener()           = default;
    virtual ~IRxListener()  = default;

#   ifdef NOTEPAD_ALGO_BAZX
    virtual void onDatasetReady() = 0;
#   endif
};


} /* namespace notepad */


#endif // NOTEPAD_IRXLISTENER_H
