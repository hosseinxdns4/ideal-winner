/* NOTepad
 * Copyright 2010      Jeff Garzik <jgarzik@pobox.com>
 * Copyright 2012-2014 pooler      <pooler@litecoinpool.org>
 * Copyright 2014      Lucas Jones <https://github.com/lucasjones>
 * Copyright 2014-2016 Wolf9466    <https://github.com/OhGodAPet>
 * Copyright 2016      Jay D Dee   <jayddee246@gmail.com>
 * Copyright 2017-2018 amd    <https://github.com/fireice-uk>, <https://github.com/psychocrypt>
 * Copyright 2018      Lee Clagett <https://github.com/vtnerd>
 * Copyright 2018-2020 SChernykh   <https://github.com/SChernykh>
 * Copyright 2016-2020 NOTepad       <https://github.com/notepad>, <support@notepad.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTEPAD_CPULAUNCHDATA_H
#define NOTEPAD_CPULAUNCHDATA_H


#include "base/crypto/Algorithm.h"
#include "crypto/cn/CnHash.h"
#include "crypto/common/Assembly.h"
#include "crypto/common/Nonce.h"


namespace notepad {


class CpuConfig;
class CpuThread;
class Mci;


class CpuLaunchData
{
public:
    CpuLaunchData(const Mci *mci, const Algorithm &algorithm, const CpuConfig &config, const CpuThread &thread, size_t threads, const std::vector<int64_t>& affinities);

    bool isEqual(const CpuLaunchData &other) const;
    CnHash::AlgoVariant av() const;

    inline constexpr static Nonce::Backend backend()            { return Nonce::CPU; }

    inline bool operator!=(const CpuLaunchData &other) const    { return !isEqual(other); }
    inline bool operator==(const CpuLaunchData &other) const    { return isEqual(other); }

    static const char *tag();

    const Algorithm algorithm;
    const Assembly assembly;
    const bool hugePages;
    const bool hwAES;
    const bool yield;
    const int priority;
    const int64_t affinity;
    const Mci *mci;
    const size_t threads;
    const uint32_t intensity;
    const std::vector<int64_t> affinities;
};


} // namespace notepad


#endif /* NOTEPAD_CPULAUNCHDATA_H */
